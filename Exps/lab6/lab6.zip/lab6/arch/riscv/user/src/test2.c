#include "stdio.h"
#include "proc.h"

int main() {
  printf("hello world!\n");
  return 0;
}

